Summary
===============================

Summary of progress in January 2022

- Item 1
- Item 2
- Item 3
- ...
