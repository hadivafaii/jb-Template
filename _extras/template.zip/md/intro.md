Welcome
===============================

In this tutorial I will demonstrate how you can organize your project efficiently using jupyter books.  The tutorial itself is prepared in a notebook, click on January *Updates* --> *Jan 23rd, 2022* to see it.
