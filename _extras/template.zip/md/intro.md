Welcome
===============================

In this tutorial I will show how to organize your project using jupyter books.  Too see the tutorial click on January Updates --> Jan 23rd, 2022.
